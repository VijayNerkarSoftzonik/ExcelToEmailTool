import sys
import os
from PyQt5.QtWidgets import QApplication
from ui_component.main_window import MainWindow

def main():
    app = QApplication(sys.argv)

    # with open("resources/dark_theme.qss", "r") as f:
    #     app.setStyleSheet(f.read())
    base_dir = os.path.dirname(os.path.abspath(__file__))
    theme_path = os.path.join(base_dir, "resources", "dark_theme.qss")

    if os.path.exists(theme_path):
        with open(theme_path, "r") as f:
            app.setStyleSheet(f.read())

    window = MainWindow()
    window.show()

    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
