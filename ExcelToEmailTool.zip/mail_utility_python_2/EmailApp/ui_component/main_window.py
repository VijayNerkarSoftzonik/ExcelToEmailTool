from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QPushButton, QFileDialog, QLineEdit,
    QTabWidget, QFormLayout, QSpinBox, QProgressBar, QStyleFactory
)
from PyQt5.QtGui import QPalette, QColor, QFont
from PyQt5.QtCore import Qt

from modules.sorter import sort_excel_file
from modules.mailer import EmailSenderThread
from PyQt5.QtWidgets import QTextEdit



class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Excel Mailer")
        self.resize(600, 400)
        self.init_ui()
        self.apply_dark_theme()

    def init_ui(self):
        layout = QVBoxLayout()
        self.tabs = QTabWidget()

        self.tabs.addTab(self.sort_tab(), "📑 Sort Excel")
        self.tabs.addTab(self.mail_tab(), "📧 Send Mails")
        self.tabs.currentChanged.connect(self.reset_progress)

        layout.addWidget(self.tabs)
        self.setLayout(layout)

    def apply_dark_theme(self):
        dark_palette = QPalette()
        dark_palette.setColor(QPalette.Window, QColor(30, 30, 30))
        dark_palette.setColor(QPalette.WindowText, Qt.white)
        dark_palette.setColor(QPalette.Base, QColor(45, 45, 45))
        dark_palette.setColor(QPalette.AlternateBase, QColor(60, 60, 60))
        dark_palette.setColor(QPalette.ToolTipBase, Qt.white)
        dark_palette.setColor(QPalette.ToolTipText, Qt.white)
        dark_palette.setColor(QPalette.Text, Qt.white)
        dark_palette.setColor(QPalette.Button, QColor(53, 53, 53))
        dark_palette.setColor(QPalette.ButtonText, Qt.white)
        dark_palette.setColor(QPalette.BrightText, Qt.red)
        dark_palette.setColor(QPalette.Highlight, QColor(100, 100, 255))
        dark_palette.setColor(QPalette.HighlightedText, Qt.black)

        self.setPalette(dark_palette)
        self.setStyle(QStyleFactory.create("Fusion"))

    def styled_button(self, text):
        button = QPushButton(text)
        button.setStyleSheet("""
            QPushButton {
                background-color: #0072B2; /* color blind safe blue */
                color: white;
                border-radius: 8px;
                padding: 8px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #005F8C;
            }
        """)
        return button
    
    def append_log(self, message):
        self.log_output.append(message)

    def sort_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()

        self.input_file_btn = self.styled_button("Select Input Excel File")
        self.input_file_btn.clicked.connect(self.select_input_file)

        self.output_file_btn = self.styled_button("Select Output Excel File Location")
        self.output_file_btn.clicked.connect(self.select_output_file)

        self.sort_btn = self.styled_button("Sort File")
        self.sort_btn.clicked.connect(self.run_sort)

        self.sort_progress = QProgressBar()
        self.sort_progress.setValue(0)
        self.sort_progress.setTextVisible(True)

        layout.addWidget(self.input_file_btn)
        layout.addWidget(self.output_file_btn)
        layout.addWidget(self.sort_btn)
        layout.addWidget(self.sort_progress)

        tab.setLayout(layout)
        return tab
    def mail_tab(self):
        tab = QWidget()
        layout = QFormLayout()

        self.email_input = QLineEdit()
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        #self.subject_input = QLineEdit()

        self.mail_file_btn = self.styled_button("Select Input Excel File")
        self.mail_file_btn.clicked.connect(self.select_mail_file)

        self.start_row = QSpinBox()
        self.max_count = QSpinBox()

        self.send_mail_btn = self.styled_button("Send Mails")
        self.send_mail_btn.clicked.connect(self.run_mail)

        self.mail_progress = QProgressBar()
        self.mail_progress.setValue(0)
        self.mail_progress.setTextVisible(True)

        layout.addRow("Your Email:", self.email_input)
        layout.addRow("Password:", self.password_input)
        #layout.addRow("Subject:", self.subject_input)
        layout.addRow("Starting Row:", self.start_row)
        layout.addRow("Max Count:", self.max_count)

        #self.email_input.setText("vijay.nerkar@softzonik.com")
        #self.password_input.setText("Mobile@Sgn$4")   

        layout.addRow(self.mail_file_btn)
        layout.addRow(self.send_mail_btn)
        layout.addRow(self.mail_progress)

        # ✅ Add this block
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setPlaceholderText("Log messages will appear here...")
        layout.addRow("Log Output:", self.log_output)

        tab.setLayout(layout)
        return tab

    def reset_progress(self):
        self.sort_progress.setValue(0)
        self.mail_progress.setValue(0)

    def select_input_file(self):
        file, _ = QFileDialog.getOpenFileName(self, "Select Excel File", "", "Excel Files (*.xlsx *.xls)")
        if file:
            self.input_file_btn.setText(file)

    def select_output_file(self):
        file, _ = QFileDialog.getSaveFileName(self, "Save Processed File", "", "Excel Files (*.xlsx)")
        if file:
            self.output_file_btn.setText(file)

    def select_mail_file(self):
        file, _ = QFileDialog.getOpenFileName(self, "Select Excel File", "", "Excel Files (*.xlsx)")
        if file:
            self.mail_file_btn.setText(file)

    def run_sort(self):
        self.sort_progress.setValue(0)
        sort_excel_file(
            input_path=self.input_file_btn.text(),
            output_path=self.output_file_btn.text(),
            progress_bar=self.sort_progress
        )

    def run_mail(self):
        self.mail_progress.setValue(0)

        # Create and configure the thread
        self.email_thread = EmailSenderThread(
            input_file=self.mail_file_btn.text(),
            sender_email=self.email_input.text(),
            password=self.password_input.text(),
            #subject=self.subject_input.text(),
            start_row=self.start_row.value(),
            max_count=self.max_count.value()
        )

        # Connect signals to update UI safely from the thread
        self.email_thread.progress_signal.connect(self.mail_progress.setValue)
        self.email_thread.log_signal.connect(self.append_log)

        # Start the thread
        self.email_thread.start()

