import os
from datetime import datetime
import logging

def log_event(module, message):
    os.makedirs("logs", exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(f"logs/{module}.log", "a") as f:
        f.write(f"[{timestamp}] {message}\n")

def setup_logging(name):
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)

    #log_filename = f"log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    log_filename = f"log_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{name}.txt"
    log_path = os.path.join(log_dir, log_filename)

    logger = logging.getLogger("EmailLogger")
    logger.setLevel(logging.INFO)

    file_handler = logging.FileHandler(log_path)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)

    # Avoid duplicate logs
    if not logger.hasHandlers():
        logger.addHandler(file_handler)

    return logger



logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("logs/app.log"),
        logging.StreamHandler()
    ]
)
